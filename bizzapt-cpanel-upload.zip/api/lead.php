<?php
/**
 * Bizzapt lead endpoint.
 *
 * Receives sign-ins, walkthrough requests and "projects viewed" notes from the
 * Our Work page, emails them to the Bizzapt inbox, and appends a backup copy
 * to a private log. Returns JSON: {"ok":true} or {"ok":false,"error":"..."}.
 */

declare(strict_types=1);

// ---------------------------------------------------------------- settings
const LEAD_TO        = 'info@bizzapt.com';
const MAIL_FROM      = 'no-reply@bizzapt.com';      // must be on your domain
const MAIL_FROM_NAME = 'Bizzapt Website';
const ALLOWED_HOSTS  = ['bizzapt.com', 'www.bizzapt.com', 'localhost', '127.0.0.1'];
const RATE_LIMIT     = 8;      // submissions per IP...
const RATE_WINDOW    = 3600;   // ...per hour
const DATA_DIR       = __DIR__ . '/data';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

function reply(int $code, array $body): void {
    http_response_code($code);
    echo json_encode($body);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    reply(405, ['ok' => false, 'error' => 'POST only']);
}

// Only accept submissions from our own pages.
$origin = $_SERVER['HTTP_ORIGIN'] ?? ($_SERVER['HTTP_REFERER'] ?? '');
$host = $origin ? strtolower((string) parse_url($origin, PHP_URL_HOST)) : '';
if ($host !== '' && !in_array($host, ALLOWED_HOSTS, true)) {
    reply(403, ['ok' => false, 'error' => 'Not allowed']);
}

// Read form data or JSON.
$in = $_POST;
if (!$in) {
    $raw = file_get_contents('php://input') ?: '';
    $json = json_decode($raw, true);
    if (is_array($json)) $in = $json;
}

// Honeypot: bots fill hidden fields. Pretend success, do nothing.
if (!empty($in['_gotcha'])) {
    reply(200, ['ok' => true]);
}

function field(array $in, string $key, int $max = 300): string {
    $v = isset($in[$key]) && is_scalar($in[$key]) ? (string) $in[$key] : '';
    $v = trim(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $v) ?? '');
    return mb_substr($v, 0, $max);
}

$type    = field($in, 'form_type', 60) ?: 'Website lead';
$name    = field($in, 'name', 120);
$email   = field($in, 'email', 160);
$company = field($in, 'company', 160);
$phone   = field($in, 'phone', 40);
$data = [
    'Type'               => $type,
    'Name'               => $name,
    'Email'              => $email,
    'Company'            => $company,
    'Phone / WhatsApp'   => $phone,
    'Role'               => field($in, 'role', 80),
    'Looking for'        => field($in, 'looking_for', 120),
    'Project of interest'=> field($in, 'project_of_interest', 160) ?: field($in, 'project', 160),
    'Projects viewed'    => field($in, 'projects_viewed', 600),
    'Business stage'     => field($in, 'stage', 120),
    'Closest problem'    => field($in, 'accomplishment', 160),
    'Message'            => field($in, 'message', 3000),
    'OK to contact'      => field($in, 'contact_ok', 10),
    'Page'               => field($in, 'page', 300),
];

if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    reply(422, ['ok' => false, 'error' => 'Name and a valid email are required']);
}

// Storage: private folder, blocked from the web by api/data/.htaccess.
if (!is_dir(DATA_DIR)) {
    @mkdir(DATA_DIR, 0750, true);
}

// Rate limit per IP (hashed, so raw IPs are never stored).
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$ipKey = hash('sha256', $ip . '|bizzapt');
$rateFile = DATA_DIR . '/rate.json';
$now = time();
$rates = [];
if (is_file($rateFile)) {
    $rates = json_decode((string) @file_get_contents($rateFile), true) ?: [];
}
foreach ($rates as $k => $stamps) {
    $rates[$k] = array_values(array_filter((array) $stamps, fn($t) => $t > $now - RATE_WINDOW));
    if (!$rates[$k]) unset($rates[$k]);
}
if (count($rates[$ipKey] ?? []) >= RATE_LIMIT) {
    reply(429, ['ok' => false, 'error' => 'Too many requests, try again later']);
}
$rates[$ipKey][] = $now;
@file_put_contents($rateFile, json_encode($rates), LOCK_EX);

// Backup log: one JSON line per lead.
$record = ['time' => date('c'), 'ip_hash' => substr($ipKey, 0, 12)] + array_filter($data, fn($v) => $v !== '');
@file_put_contents(DATA_DIR . '/leads.jsonl', json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND | LOCK_EX);

// Email.
$subjectBits = [$type . ':', $name];
if ($company !== '') $subjectBits[] = '(' . $company . ')';
if ($data['Project of interest'] !== '') $subjectBits[] = '— ' . $data['Project of interest'];
$subject = '=?UTF-8?B?' . base64_encode(implode(' ', $subjectBits)) . '?=';

$rowsText = '';
$rowsHtml = '';
foreach ($data as $label => $value) {
    if ($value === '') continue;
    $rowsText .= str_pad($label . ':', 22) . $value . "\n";
    $rowsHtml .= '<tr><td style="padding:8px 14px;color:#60435b;font:600 13px Arial;white-space:nowrap;vertical-align:top">'
        . htmlspecialchars($label) . '</td><td style="padding:8px 14px;font:14px Arial;color:#211d1b">'
        . nl2br(htmlspecialchars($value)) . '</td></tr>';
}
$when = date('j M Y, g:i a T');
$replyLink = 'mailto:' . rawurlencode($email);

$text = "New {$type} from bizzapt.com\n\n{$rowsText}\nReceived: {$when}\nReply directly to this email to answer {$name}.\n";
$html = '<!doctype html><html><body style="margin:0;background:#f4eee6;padding:24px">'
    . '<table role="presentation" style="max-width:620px;margin:auto;background:#fff;border-radius:12px;overflow:hidden">'
    . '<tr><td style="background:#211d1b;color:#d7e762;padding:18px 22px;font:700 13px Arial;letter-spacing:.08em;text-transform:uppercase">'
    . htmlspecialchars($type) . ' · bizzapt.com</td></tr>'
    . '<tr><td style="padding:18px 8px"><table role="presentation" style="width:100%">' . $rowsHtml . '</table></td></tr>'
    . '<tr><td style="padding:0 22px 22px"><a href="' . htmlspecialchars($replyLink) . '" style="display:inline-block;background:#d7e762;color:#211d1b;text-decoration:none;font:700 13px Arial;padding:12px 18px;border-radius:999px">Reply to '
    . htmlspecialchars($name) . '</a><p style="font:12px Arial;color:#777;margin:14px 0 0">Received ' . htmlspecialchars($when) . '</p></td></tr>'
    . '</table></body></html>';

$boundary = 'bz_' . bin2hex(random_bytes(8));
$headers = [
    'MIME-Version: 1.0',
    'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM . '>',
    'Reply-To: ' . (preg_replace('/[\r\n<>"]/', '', $name) ?: 'Visitor') . ' <' . $email . '>',
    'X-Mailer: Bizzapt',
    'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
];
$body = "--{$boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n{$text}\r\n"
      . "--{$boundary}\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n{$html}\r\n"
      . "--{$boundary}--";

$sent = @mail(LEAD_TO, $subject, $body, implode("\r\n", $headers), '-f' . MAIL_FROM);

if (!$sent) {
    // Saved in the log, but tell the page so it can use the backup route.
    reply(502, ['ok' => false, 'error' => 'Mail not sent', 'saved' => true]);
}
reply(200, ['ok' => true]);