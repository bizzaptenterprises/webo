// About page: gentle fade-up as sections and cards scroll into view.
const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if (!reduced && 'IntersectionObserver' in window) {
  document.body.classList.add('pl-js');
  const targets = document.querySelectorAll([
    '.about-story > div', '.about-brand-card',
    '.fn2-card',
    '.about-values-heading', '.values-grid article',
    '.about-promise > *', '.philosophy header', '.belief',
    '.about-thinking > p, .about-thinking > h2', '.about-thinking-grid article',
    '.tm2-head', '.tm2-card', '.tm2-standard',
    '.about-manifesto > *',
  ].join(','));
  const groups = new Map();
  targets.forEach((el) => {
    const parent = el.parentElement;
    const i = groups.get(parent) || 0;
    groups.set(parent, i + 1);
    el.style.setProperty('--pl-d', `${Math.min(i, 5) * 0.08}s`);
    el.classList.add('pl-reveal');
  });
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  targets.forEach((el) => io.observe(el));
}
