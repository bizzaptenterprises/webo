// Homepage hero background: a 3D particle wave (dots rippling from slate blue to mauve).
// Pauses when off-screen or the tab is hidden, and holds still for reduced-motion users.
const hero = document.querySelector('.net-hero');
const canvas = hero?.querySelector('.net-hero-canvas');
if (canvas) {
  const ctx = canvas.getContext('2d');
  const still = matchMedia('(prefers-reduced-motion: reduce)');
  const PALETTES = {
    dark: { from: [110, 150, 170], to: [201, 150, 185], alpha: [.22, .78] },
    light: { from: [78, 110, 125], to: [96, 67, 91], alpha: [.16, .6] }
  };
  const palette = () => PALETTES[document.documentElement.getAttribute('data-theme') === 'inverted' ? 'light' : 'dark'];
  let w = 0, h = 0, t = 0, running = false, frame = 0;

  function fit() {
    const ratio = Math.min(devicePixelRatio || 1, innerWidth < 860 ? 1.5 : 2), rect = canvas.getBoundingClientRect();
    w = rect.width; h = rect.height;
    canvas.width = w * ratio; canvas.height = h * ratio;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  }

  let last = 0;
  function draw(now = 0) {
    frame = 0;
    // ~30 fps is plenty for a slow wave and halves the work on phones
    if (running && !still.matches && now - last < 32) { frame = requestAnimationFrame(draw); return; }
    last = now;
    ctx.clearRect(0, 0, w, h);
    if (!still.matches) t += .024;
    const pal = palette(), small = w < 860;
    const cols = small ? 34 : 64, rows = small ? 14 : 22, BUCKETS = 6;
    // batch dots into a few colour buckets per row: one fill call per bucket instead of one per dot
    for (let r = 0; r < rows; r++) {
      const z = r / (rows - 1), persp = .35 + z * .9;
      const base = h * (small ? .58 : .48) + z * h * (small ? .46 : .56);
      const alpha = pal.alpha[0] + z * (pal.alpha[1] - pal.alpha[0]);
      const size = 1.2 + z * 3;
      const paths = Array.from({ length: BUCKETS }, () => new Path2D());
      for (let c = 0; c < cols; c++) {
        const u = c / (cols - 1);
        const x = w * (small ? .5 : .6) + (u - .5) * w * 1.65 * persp;
        if (x < -4 || x > w + 4) continue;
        const y = base + (24 + z * 40) * Math.sin(u * 7 + t * 1.4 + z * 3) * Math.cos(z * 5 - t * .8);
        paths[Math.min(BUCKETS - 1, Math.floor(u * BUCKETS))].rect(x - size / 2, y - size / 2, size, size);
      }
      paths.forEach((path, k) => {
        const u = (k + .5) / BUCKETS;
        ctx.fillStyle = `rgba(${pal.from.map((v, i) => Math.round(v * (1 - u) + pal.to[i] * u))},${alpha})`;
        ctx.fill(path);
      });
    }
    if (running && !still.matches) frame = requestAnimationFrame(draw);
  }

  function setRunning(on) {
    running = on; hero.classList.toggle('is-offscreen', !on);
    if (on && !frame) frame = requestAnimationFrame(draw);
  }
  let resizeTimer;
  addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      const rect = canvas.getBoundingClientRect();
      if (Math.abs(rect.width - w) < 1 && Math.abs(rect.height - h) < 1) return;
      fit(); if (!running || still.matches) draw();
    }, 150);
  });
  still.addEventListener?.('change', () => setRunning(running));
  document.addEventListener('bizzapt:themechange', () => { if (!running || still.matches) draw(); });
  fit(); draw();
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(([entry]) => setRunning(entry.isIntersecting && !document.hidden)).observe(hero);
  } else setRunning(true);
  document.addEventListener('visibilitychange', () => setRunning(!document.hidden && hero.getBoundingClientRect().bottom > 0));
}
