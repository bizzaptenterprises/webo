// About v2: gentle staggered reveal as sections scroll in. Content is visible without JavaScript.
const page = document.body;
if (page.classList.contains('ab-page') && 'IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const groups = ['.ab-hero-copy > *', '.ab-founder > *', '.ab-tile', '.ab-value', '.ab-belief', '.ab-nodes li', '.ab-person', '.ab-head', '.ab-promise-in', '.ab-cta > :not(.ab-cta-glow)'];
  const items = [];
  groups.forEach(sel => document.querySelectorAll(sel).forEach((el, i) => { el.classList.add('ab-rv'); el.style.setProperty('--d', i % 6); items.push(el); }));
  page.classList.add('ab-js');
  const io = new IntersectionObserver(entries => entries.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }), { rootMargin: '0px 0px -8% 0px' });
  items.forEach(el => io.observe(el));
}
