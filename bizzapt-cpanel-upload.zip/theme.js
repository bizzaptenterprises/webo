// Moon / sun switch. Every page opens as designed (dark hero, mixed sections). The switch flips every
// section (light <-> dark) by setting data-theme="inverted" on <html>; the tiny script in <head> applies a
// remembered choice before the page paints.
(() => {
  const root = document.documentElement;
  const KEY = 'bizzapt-colours';
  const buttons = document.querySelectorAll('.theme-toggle');
  const flipped = () => root.getAttribute('data-theme') === 'inverted';

  // the footer sits on dark by default (white logo); when flipped it sits on light (regular logo)
  const footerLogos = [...document.querySelectorAll('.bzf-brand img')];
  footerLogos.forEach(img => { img.dataset.logoDefault = img.getAttribute('src'); });

  function sync() {
    const inv = flipped();
    footerLogos.forEach(img => {
      const src = inv ? img.dataset.logoDefault.replace('brand-logo-dark.png', 'brand-logo-light-v2.png') : img.dataset.logoDefault;
      if (img.getAttribute('src') !== src) img.setAttribute('src', src);
    });
    buttons.forEach(button => {
      button.setAttribute('aria-pressed', String(inv));
      button.setAttribute('aria-label', inv ? 'Switch colours back' : 'Switch colours');
      button.title = inv ? 'Dark mode' : 'Light mode';
    });
  }

  function setState(state) {
    root.classList.add('theme-switching');
    root.setAttribute('data-theme', state);
    try { localStorage.setItem(KEY, state); } catch (error) { /* private mode: lasts for this page only */ }
    sync();
    // let the navbar re-check the colour behind it and pick the matching real logo
    window.dispatchEvent(new Event('resize'));
    document.dispatchEvent(new CustomEvent('bizzapt:themechange', { detail: { state } }));
    setTimeout(() => {
      root.classList.remove('theme-switching');
      window.dispatchEvent(new Event('resize')); // re-check once the colour fade has finished
    }, 450);
  }

  buttons.forEach(button => button.addEventListener('click', () => setState(flipped() ? 'default' : 'inverted')));
  sync();
})();
