// "Our work": arrows, dots and mouse-drag for the client-project row. Text on the page is unchanged.
const row = document.querySelector('.work-page .project-gallery');
if (row) {
  const cards = [...row.querySelectorAll(':scope > .project-card')];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const icon = d => `<svg aria-hidden="true" viewBox="0 0 24 24"><path d="${d}"/></svg>`;
  const controls = document.createElement('div');
  controls.className = 'wk-controls';
  controls.innerHTML = `<div class="wk-dots">${cards.map((c, i) => `<button type="button" aria-label="Go to project ${i + 1}"></button>`).join('')}</div>
    <div class="wk-arrows"><button type="button" aria-label="Previous project">${icon('M15 6l-6 6 6 6')}</button><button type="button" aria-label="Next project">${icon('M9 6l6 6-6 6')}</button></div>`;
  row.after(controls);
  const dots = [...controls.querySelectorAll('.wk-dots button')];
  const [prev, next] = controls.querySelectorAll('.wk-arrows button');
  const left0 = () => cards[0].offsetLeft;
  const current = () => {
    let best = 0, dist = Infinity;
    cards.forEach((c, i) => { const d = Math.abs(c.offsetLeft - left0() - row.scrollLeft); if (d < dist) { dist = d; best = i; } });
    return best;
  };
  const goTo = i => { const c = cards[Math.max(0, Math.min(cards.length - 1, i))]; row.scrollTo({ left: c.offsetLeft - left0(), behavior: reduce.matches ? 'auto' : 'smooth' }); };
  function update() {
    const max = row.scrollWidth - row.clientWidth, atEnd = row.scrollLeft >= max - 2;
    const i = atEnd && max > 2 ? cards.length - 1 : current();
    dots.forEach((d, k) => d.setAttribute('aria-current', String(k === i)));
    prev.disabled = row.scrollLeft <= 2; next.disabled = atEnd;
    row.classList.toggle('at-end', atEnd);
  }
  let frame = 0;
  const schedule = () => { if (!frame) frame = requestAnimationFrame(() => { frame = 0; update(); }); };
  row.addEventListener('scroll', schedule, { passive: true });
  addEventListener('resize', schedule);
  prev.addEventListener('click', () => goTo(current() - 1));
  next.addEventListener('click', () => goTo(current() + 1));
  dots.forEach((d, i) => d.addEventListener('click', () => goTo(i)));

  // mouse drag; clicks inside cards (slideshow, details, links) still work when not dragged
  let startX = 0, startLeft = 0, down = false, moved = false;
  row.addEventListener('pointerdown', e => {
    if (e.pointerType !== 'mouse' || e.target.closest('a, button, summary, input')) return;
    down = true; moved = false; startX = e.clientX; startLeft = row.scrollLeft;
  });
  addEventListener('pointermove', e => {
    if (!down) return;
    const dx = e.clientX - startX;
    if (!moved && Math.abs(dx) > 6) { moved = true; row.classList.add('is-dragging'); }
    if (moved) row.scrollLeft = startLeft - dx;
  });
  addEventListener('pointerup', () => {
    if (!down) return;
    down = false; row.classList.remove('is-dragging');
    if (moved) goTo(current());
  });
  row.addEventListener('click', e => { if (moved) { e.preventDefault(); e.stopPropagation(); moved = false; } }, true);
  update();
}
