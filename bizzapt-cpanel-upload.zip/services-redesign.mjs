// "How we help": turns the seven problem cards into tabs (titles on the left, details on the right).
// Uses the cards' own text, so nothing is rewritten. Without JavaScript the cards still show as before.
const grid = document.querySelector('.service-problems .service-problem-grid');
if (grid) {
  const cards = [...grid.querySelectorAll('.service-problem-card')];
  const wrap = document.createElement('div');
  wrap.className = 'sv-tabs';
  const list = document.createElement('div');
  list.className = 'sv-tablist';
  list.setAttribute('aria-label', 'Problems we solve');
  const panels = document.createElement('div');
  panels.className = 'sv-panels';
  const progress = document.createElement('div');
  progress.className = 'sv-progress';
  progress.setAttribute('aria-hidden', 'true');

  const tabs = cards.map((card, i) => {
    const id = `sv-problem-${i + 1}`;
    card.id = id;
    card.setAttribute('role', 'region');
    const tab = document.createElement('button');
    tab.type = 'button';
    tab.className = 'sv-tab';
    tab.id = `${id}-tab`;
    tab.setAttribute('aria-controls', id);
    card.setAttribute('aria-labelledby', tab.id);
    tab.innerHTML = `<span class="sv-tab-num">${card.querySelector(':scope > span')?.textContent ?? ''}</span><span class="sv-tab-title"></span><svg aria-hidden="true" class="sv-tab-arrow" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>`;
    tab.querySelector('.sv-tab-title').textContent = card.querySelector('h3')?.textContent ?? '';
    list.append(tab);
    panels.append(card);
    progress.append(document.createElement('i'));
    return tab;
  });
  panels.append(progress);
  wrap.append(list, panels);
  grid.replaceWith(wrap);

  function select(i, focus = false) {
    tabs.forEach((tab, k) => {
      const on = k === i;
      tab.setAttribute('aria-pressed', String(on));
      cards[k].classList.toggle('is-active', on);
      cards[k].hidden = false;
      progress.children[k].classList.toggle('on', k <= i);
    });
    if (focus) tabs[i].focus();
    if (matchMedia('(max-width: 860px)').matches) tabs[i].scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'smooth' });
  }
  tabs.forEach((tab, i) => {
    tab.addEventListener('click', () => select(i));
    tab.addEventListener('keydown', e => {
      const keys = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 };
      if (e.key in keys) { e.preventDefault(); select((i + keys[e.key] + tabs.length) % tabs.length, true); }
      if (e.key === 'Home') { e.preventDefault(); select(0, true); }
      if (e.key === 'End') { e.preventDefault(); select(tabs.length - 1, true); }
    });
  });
  select(0);
}

// stagger the connection steps as they are redrawn
const path = document.querySelector('.solution-puzzle [data-connection-path]');
if (path) {
  const number = () => [...path.children].forEach((li, i) => li.style.setProperty('--n', i));
  new MutationObserver(number).observe(path, { childList: true });
  number();
}

// "One example" as an app window: the eight pieces become the sidebar, the chosen connection
// shows as layered glass step cards. All wording comes from the existing section and its data.
const puzzle = document.querySelector('.solution-puzzle');
const side = puzzle?.querySelector('.puzzle-grid');
const story = puzzle?.querySelector('.connection-story');
if (side && story) {
  const app = document.createElement('div');
  app.className = 'sv-app';
  const bar = document.createElement('div');
  bar.className = 'sv-app-bar';
  bar.setAttribute('aria-hidden', 'true');
  bar.innerHTML = '<i></i><i></i><i></i>';
  const label = story.querySelector(':scope > .section-tag')?.cloneNode(true);
  if (label) {
    label.className = 'connection-label';
    label.setAttribute('aria-hidden', 'true');
    const copy = label.querySelector('[data-connection-label]');
    if (copy) { copy.removeAttribute('data-connection-label'); copy.className = 'connection-label-copy'; }
    bar.append(label);
  }
  const body = document.createElement('div');
  body.className = 'sv-app-body';
  side.before(app);
  body.append(side, story);
  app.append(bar, body);
  const flow = document.createElement('div');
  flow.className = 'sv-flowbar';
  flow.setAttribute('aria-hidden', 'true');
  const pathList = story.querySelector('[data-connection-path]');
  pathList.after(flow);
  const pieces = [...side.querySelectorAll('[data-piece]')];
  const liveLabel = story.querySelector('[data-connection-label]');
  function decorate() {
    if (label && liveLabel) label.querySelector('.connection-label-copy').textContent = liveLabel.textContent;
    [...pathList.children].forEach((li, i) => {
      if (li.querySelector('.sv-step-name')) return;
      li.style.setProperty('--n', i);
      const name = li.textContent.trim();
      const piece = pieces.find(p => p.querySelector('.piece-content > span')?.textContent.trim() === name);
      li.textContent = '';
      const icon = document.createElement('span');
      icon.className = 'sv-step-icon';
      icon.setAttribute('aria-hidden', 'true');
      const svg = piece?.querySelector('.piece-content > svg');
      if (svg) icon.append(svg.cloneNode(true));
      const text = document.createElement('span');
      text.className = 'sv-step-name';
      text.textContent = name;
      li.append(icon, text);
    });
  }
  new MutationObserver(decorate).observe(pathList, { childList: true });
  decorate();
}
