// "How we work": staggered reveal, plus arrows / dots / mouse-drag for the sideways row on smaller screens.
const section = document.querySelector('.work-timeline');
const list = section?.querySelector('.work-timeline-steps');
if (list) {
  const steps = [...list.children];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  steps.forEach((li, i) => li.style.setProperty('--i', i));

  // reveal once, when the row scrolls into view
  if ('IntersectionObserver' in window && !reduce.matches) {
    section.classList.add('wt-ready');
    const io = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { section.classList.add('wt-in'); io.disconnect(); }
    }, { threshold: .2 });
    io.observe(list);
  }

  // controls (added by script, so the page text is unchanged)
  const icon = d => `<svg aria-hidden="true" viewBox="0 0 24 24"><path d="${d}"/></svg>`;
  const controls = document.createElement('div');
  controls.className = 'wt-controls';
  controls.innerHTML = `<div class="wt-dots">${steps.map((_, i) => `<button type="button" aria-label="Go to step ${i + 1}"></button>`).join('')}</div>
    <div class="wt-arrows"><button type="button" data-dir="-1" aria-label="Previous step">${icon('M15 6l-6 6 6 6')}</button><button type="button" data-dir="1" aria-label="Next step">${icon('M9 6l6 6-6 6')}</button></div>`;
  list.after(controls);
  const dots = [...controls.querySelectorAll('.wt-dots button')];
  const [prev, next] = controls.querySelectorAll('.wt-arrows button');

  const stepWidth = () => (steps[1]?.offsetLeft ?? 0) - steps[0].offsetLeft || list.clientWidth;
  const current = () => Math.max(0, Math.min(steps.length - 1, Math.round(list.scrollLeft / stepWidth())));
  const goTo = i => list.scrollTo({ left: steps[Math.max(0, Math.min(steps.length - 1, i))].offsetLeft - steps[0].offsetLeft, behavior: reduce.matches ? 'auto' : 'smooth' });

  function update() {
    const max = list.scrollWidth - list.clientWidth;
    const scrollable = max > 2;
    const atEnd = list.scrollLeft >= max - 2;
    const i = atEnd && scrollable ? steps.length - 1 : current();
    dots.forEach((d, k) => d.setAttribute('aria-current', String(k === i)));
    steps.forEach((s, k) => s.classList.toggle('is-current', scrollable && k === i));
    prev.disabled = list.scrollLeft <= 2;
    next.disabled = atEnd;
    list.classList.toggle('at-end', atEnd);
  }
  let frame = 0;
  const schedule = () => { if (!frame) frame = requestAnimationFrame(() => { frame = 0; update(); }); };
  list.addEventListener('scroll', schedule, { passive: true });
  addEventListener('resize', schedule);
  prev.addEventListener('click', () => goTo(current() - 1));
  next.addEventListener('click', () => goTo(current() + 1));
  dots.forEach((d, i) => d.addEventListener('click', () => goTo(i)));
  list.addEventListener('keydown', e => {
    if (e.key === 'ArrowRight') { e.preventDefault(); goTo(current() + 1); }
    if (e.key === 'ArrowLeft') { e.preventDefault(); goTo(current() - 1); }
  });

  // mouse drag (touch already swipes natively)
  let startX = 0, startLeft = 0, dragging = false, moved = false;
  list.addEventListener('pointerdown', e => {
    if (e.pointerType !== 'mouse' || list.scrollWidth <= list.clientWidth) return;
    dragging = true; moved = false; startX = e.clientX; startLeft = list.scrollLeft;
    list.classList.add('is-dragging');
  });
  addEventListener('pointermove', e => {
    if (!dragging) return;
    const dx = e.clientX - startX;
    if (Math.abs(dx) > 4) moved = true;
    list.scrollLeft = startLeft - dx;
  });
  addEventListener('pointerup', () => {
    if (!dragging) return;
    dragging = false; list.classList.remove('is-dragging');
    if (moved) goTo(current());
  });
  list.addEventListener('click', e => { if (moved) { e.preventDefault(); moved = false; } }, true);
  update();
}
