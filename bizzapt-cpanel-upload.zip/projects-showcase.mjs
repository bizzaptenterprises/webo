// Our Work page: flagship carousel (row 1), lab strip (row 2), case drawer and
// the sign-in that unlocks full case studies.
import { featured, lab, allProjects } from './projects-data.mjs?v=12';

const FORM_ENDPOINT = 'https://formspree.io/f/xzebpoby';
const ACCESS_KEY = 'bz-work-access-v2';
const PENDING_KEY = 'bz-work-pending-v1';
// Send one short "what they looked at" note when a signed-in visitor leaves.
const TRACK_VIEWS = true;

const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const lerp = (a, b, t) => a + (b - a) * t;
const byId = Object.fromEntries(allProjects.map((p) => [p.id, p]));
const esc = (s = '') => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ------------------------------------------------------------------ store */

const store = {
  get(key) { try { return JSON.parse(localStorage.getItem(key)); } catch { return null; } },
  set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* private mode */ } },
  remove(key) { try { localStorage.removeItem(key); } catch { /* private mode */ } },
};

let access = store.get(ACCESS_KEY);
const viewed = new Set();

function applyAccess() {
  document.body.classList.toggle('has-work-access', Boolean(access));
  document.querySelectorAll('[data-access-label]').forEach((el) => {
    el.textContent = access ? `Viewing as ${access.name.split(' ')[0]}` : 'Fill the form to view projects';
  });
  document.querySelectorAll('[data-signout]').forEach((el) => { el.hidden = !access; });
  document.querySelectorAll('.sq-action').forEach((el) => {
    el.firstChild.textContent = access ? 'View full project ' : 'View more ';
  });
}

const LEAD_ENDPOINT = 'api/lead.php';

// Our own server first (emails the Bizzapt inbox), Formspree as a backup.
async function send(fields, { beacon = false } = {}) {
  const data = new FormData();
  Object.entries(fields).forEach(([k, v]) => data.append(k, v ?? ''));
  data.append('page', location.href);
  data.append('sent_at', new Date().toISOString());
  if (beacon && navigator.sendBeacon) return navigator.sendBeacon(LEAD_ENDPOINT, data);
  try {
    const res = await fetch(LEAD_ENDPOINT, { method: 'POST', body: data, headers: { Accept: 'application/json' } });
    const out = await res.json().catch(() => ({}));
    if (res.ok && out.ok) return true;
    if (res.status === 422 || res.status === 429) throw Object.assign(new Error(out.error || 'Rejected'), { final: true });
  } catch (err) {
    if (err.final) throw err;
  }
  const res = await fetch(FORM_ENDPOINT, { method: 'POST', body: data, headers: { Accept: 'application/json' } });
  if (!res.ok) throw new Error(`Form service returned ${res.status}`);
  return true;
}

// A sign-in that failed to send is kept and retried on the next visit.
async function flushPending() {
  const pending = store.get(PENDING_KEY);
  if (!pending) return;
  try { await send(pending); store.remove(PENDING_KEY); } catch { /* try again next visit */ }
}

/* ------------------------------------------------------------------ covers */

function cover(p, { big = false } = {}) {
  const style = `--c0:${p.art[0]};--c1:${p.art[1]};--c2:${p.art[2]}`;
  if (p.site) {
    return `<span class="cover cover-site" style="${style}"><span class="site-bar" aria-hidden="true"><i></i><i></i><i></i>${p.site.host ? `<em>${esc(p.site.host)}</em>` : ''}</span><img src="${esc(p.site.image)}" alt="${esc(p.name)} website" draggable="false" onerror="this.onerror=null;this.src=this.getAttribute('src').split('/').pop()" decoding="async" loading="${big ? 'eager' : 'lazy'}"/></span>`;
  }
  if (p.image) {
    return `<span class="cover cover-image" style="${style}"><img src="${esc(p.image)}" alt="" draggable="false" decoding="async" loading="${big ? 'eager' : 'lazy'}"/></span>`;
  }
  return `<span class="cover" style="${style}" aria-hidden="true">
    <span class="cover-grid"></span><span class="cover-orb"></span><span class="cover-ring"></span>
    <b class="cover-mono">${esc(p.mono)}</b>
    <span class="cover-kind">${esc(p.category)}</span>
  </span>`;
}

/* ------------------------------------------------- row 1: squeeze carousel */

const SHARES = [-0.06, 0.61, 0.3, 0.15];
const STRETCHED = [0, 0.71, 0.4, 0.25];
const SQUEEZED = [-0.12, 0.59, 0.28, 0.13];

function squeezeCarousel(root, slides, { onOpen }) {
  const track = root.querySelector('.sq-track');
  const strip = root.querySelector('.sq-strip');
  const copy = root.querySelector('.sq-copy');
  const section = root.closest('section') || root;
  const counter = section.querySelector('.sq-count');
  const progress = section.querySelector('.sq-progress i');
  const count = slides.length;
  const slats = clamp(count - 4, 1, 3);
  const visible = 4 + slats;
  const ms = reduced ? 0 : 950;
  const wrap = (i) => ((i % count) + count) % count;

  let cards = [];
  let column = 0;
  let slid = 0;
  let hover = -1;
  let settleTimer = 0;
  let geo = {};

  copy.innerHTML = slides.map((s, i) => `
    <div class="sq-copy-item" data-index="${i}" aria-hidden="true">
      <div class="sq-copy-text">
        <p class="sq-kicker"><span>${esc(s.kind)}</span><span>${esc(s.category)}</span></p>
        <h3>${esc(s.name)}</h3>
        <p class="sq-line"><strong>${esc(s.headline)}</strong> <span>${esc(s.teaser)}</span></p>
      </div>
      <button class="sq-action" type="button" data-open="${s.id}" tabindex="-1">View more <span aria-hidden="true">↗</span></button>
    </div>`).join('');

  const makeCard = (slide) => {
    const s = slides[slide];
    const el = document.createElement('button');
    el.type = 'button';
    el.className = 'sq-card';
    el.setAttribute('aria-label', s.name);
    el.innerHTML = `${cover(s, { big: true })}<span class="sq-label"><b>${esc(s.name)}</b><small>${esc(s.category)}</small></span>`;
    el.addEventListener('mousemove', () => {
      const col = cards.findIndex((c) => c.el === el) + column;
      if (col !== hover && col >= 0 && col <= 3) { hover = col; layout(); }
    });
    el.addEventListener('click', () => {
      const col = cards.findIndex((c) => c.el === el) + column;
      if (col === 0) onOpen(slides[slide].id);
      else step(col);
    });
    return { el, slide };
  };

  function measure() {
    const W = track.clientWidth;
    const h = track.clientHeight;
    const narrow = W < 640;
    const slat = narrow ? 5 : 8;
    const slatGap = narrow ? 5 : 8;
    const gap = narrow ? 8 : 16;
    const hero = Math.min((h * 16) / 9, W * (narrow ? 0.66 : 0.6));
    const room = Math.max(0, W - hero - slats * slatGap - 3 * gap - slats * slat);
    geo = { slat, slatGap, gap, hero, room };
    root.style.setProperty('--sq-hero', `${hero}px`);
  }

  const share = (col) => {
    if (hover < 0 || hover > 3 || reduced) return SHARES[col];
    return hover === col ? STRETCHED[col] : SQUEEZED[col];
  };
  const widthOf = (col) => {
    if (col < 0 || col > 3) return geo.slat;
    return col === 0 ? geo.hero + geo.room * share(0) : geo.room * share(col);
  };

  const front = () => cards[-column]?.slide ?? 0;

  function layout() {
    cards.forEach((card, place) => {
      const col = place + column;
      const w = widthOf(col);
      card.el.style.width = `${w}px`;
      card.el.style.marginLeft = place === 0 ? '0px' : `${col < 4 ? geo.gap : geo.slatGap}px`;
      card.el.style.borderRadius = `${Math.min(14, w / 2)}px`;
      card.el.classList.toggle('is-front', col === 0);
      card.el.tabIndex = col === 0 ? 0 : -1;
    });
    strip.style.transform = `translateX(${slid * (geo.slat + geo.gap)}px)`;
    const open = front();
    copy.querySelectorAll('.sq-copy-item').forEach((item, i) => {
      const shown = i === open;
      item.classList.toggle('is-shown', shown);
      item.setAttribute('aria-hidden', String(!shown));
      item.querySelector('.sq-action').tabIndex = shown ? 0 : -1;
    });
    if (counter) counter.textContent = `${String(open + 1).padStart(2, '0')} / ${String(count).padStart(2, '0')}`;
    if (progress) progress.style.width = `${((open + 1) / count) * 100}%`;
  }

  const still = (fn) => {
    strip.classList.add('is-still');
    fn();
    void strip.offsetWidth; // apply without animating
    strip.classList.remove('is-still');
  };

  function settle() {
    clearTimeout(settleTimer);
    settleTimer = 0;
    const extra = cards.length - visible;
    if (extra <= 0 && column === 0 && slid === 0) return;
    still(() => {
      if (column < 0) cards.splice(0, -column).forEach((c) => c.el.remove());
      if (cards.length > visible) cards.splice(visible).forEach((c) => c.el.remove());
      column = 0;
      slid = 0;
      layout();
    });
  }

  function step(by) {
    if (count < 2 || !by) return;
    settle();
    if (by > 0) {
      for (let k = 0; k < by; k += 1) {
        const card = makeCard(wrap(cards[cards.length - 1].slide + 1));
        cards.push(card);
        strip.append(card.el);
      }
      still(() => {
        // new tail cards start at slat size
        cards.slice(-by).forEach((c, k) => {
          c.el.style.width = `${geo.slat}px`;
          c.el.style.marginLeft = `${geo.slatGap}px`;
          void k;
        });
      });
      column -= by;
      slid -= by;
      layout();
    } else {
      const n = -by;
      const added = [];
      for (let k = 0; k < n; k += 1) added.unshift(makeCard(wrap(cards[0].slide - 1 - k)));
      added.slice().reverse().forEach((c) => strip.prepend(c.el));
      cards = [...added, ...cards];
      still(() => { column = -n; slid = -n; layout(); });
      column = 0;
      slid = 0;
      layout();
    }
    settleTimer = window.setTimeout(settle, ms + 40);
    restartAutoplay();
  }

  // autoplay
  let auto = 0;
  let paused = false;
  function restartAutoplay() {
    clearTimeout(auto);
    if (reduced || paused) return;
    auto = window.setTimeout(() => step(1), 6500);
  }
  root.addEventListener('mouseenter', () => { paused = true; clearTimeout(auto); });
  root.addEventListener('mouseleave', () => { paused = false; hover = -1; layout(); restartAutoplay(); });
  root.addEventListener('focusin', () => { paused = true; clearTimeout(auto); });
  root.addEventListener('focusout', () => { paused = false; restartAutoplay(); });
  root.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight') { e.preventDefault(); step(1); }
    if (e.key === 'ArrowLeft') { e.preventDefault(); step(-1); }
  });
  const scope = root.closest('section') || root;
  scope.querySelector('[data-sq-prev]')?.addEventListener('click', () => step(-1));
  scope.querySelector('[data-sq-next]')?.addEventListener('click', () => step(1));
  copy.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-open]');
    if (btn) onOpen(btn.dataset.open);
  });

  // swipe on touch screens
  let sx = null;
  track.addEventListener('pointerdown', (e) => { if (e.pointerType !== 'mouse') sx = e.clientX; });
  track.addEventListener('pointerup', (e) => {
    if (sx === null) return;
    const dx = e.clientX - sx;
    sx = null;
    if (Math.abs(dx) > 40) step(dx < 0 ? 1 : -1);
  });

  cards = Array.from({ length: visible }, (_, p) => makeCard(wrap(p)));
  cards.forEach((c) => strip.append(c.el));
  measure();
  still(layout);
  new ResizeObserver(() => { measure(); still(layout); }).observe(track);
  restartAutoplay();

  return { pause: () => { paused = true; clearTimeout(auto); }, resume: () => { paused = false; restartAutoplay(); } };
}

/* ------------------------------------------- row 2: perspective lab strip */

function perspectiveStrip(root, items, { onOpen }) {
  const stage = root.querySelector('.ps-stage');
  const strip = root.querySelector('.ps-strip');
  // Repeat the set until the loop is comfortably wider than any screen.
  let list = items.slice();
  while (list.length < 12) list = list.concat(items);

  const split = (text) => [...text].map((ch, i) => `<span style="--i:${i}">${ch === ' ' ? '&nbsp;' : esc(ch)}</span>`).join('');

  strip.innerHTML = list.map((p, i) => `
    <article class="ps-card" data-open="${p.id}" tabindex="0" role="button" aria-label="${esc(p.name)} — ${esc(p.kind)}">
      <div class="ps-num">${split(String((i % items.length) + 1).padStart(2, '0'))}</div>
      <div class="ps-art">${cover(p, { big: true })}${p.open ? '<span class="ps-lock is-open" aria-hidden="true">↗</span>' : '<span class="ps-lock" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg></span>'}</div>
      <div class="ps-text">
        <div class="ps-title">${split(p.name)}</div>
        <div class="ps-desc">${split(p.kind + ' · ' + p.category)}</div>
      </div>
    </article>`).join('');

  const cards = [...strip.children];
  const s = { target: 0, current: 0, vel: 0, rotVel: 0, rot: 0 };
  let cardW = 300;
  let step = 324;
  let hovering = false;
  let dragging = false;
  let running = false;
  let raf = 0;

  function measure() {
    const W = stage.clientWidth;
    cardW = W < 700 ? 250 : W < 1025 ? 300 : 340;
    const gap = W < 700 ? 16 : 24;
    step = cardW + gap;
    root.style.setProperty('--ps-card', `${cardW}px`);
  }

  function place() {
    const loop = list.length * step;
    const centre = stage.clientWidth / 2 - cardW / 2;
    cards.forEach((card, i) => {
      let x = i * step - s.current + centre;
      x = ((x % loop) + loop) % loop;
      if (x > loop - step) x -= loop;
      card.style.transform = `translate3d(${x}px,0,0) rotateY(${s.rot}deg)`;
    });
  }

  function tick() {
    raf = 0;
    if (!running) return;
    if (!hovering && !dragging && !reduced) s.target += 0.45;
    if (reduced) { s.current = s.target; s.rot = 0; } else {
      s.current = lerp(s.current, s.target, 0.1);
      s.vel = s.target - s.current;
      s.rotVel = lerp(s.rotVel, s.vel, 0.1);
      const want = clamp(s.rotVel * 0.9, -55, 55);
      s.rot = lerp(s.rot, want, 0.12);
    }
    place();
    raf = requestAnimationFrame(tick);
  }
  const start = () => { if (!running) { running = true; raf = requestAnimationFrame(tick); } };
  const stop = () => { running = false; if (raf) cancelAnimationFrame(raf); raf = 0; };

  stage.addEventListener('mouseenter', () => { hovering = true; });
  stage.addEventListener('mouseleave', () => { hovering = false; });

  stage.addEventListener('wheel', (e) => {
    const sideways = Math.abs(e.deltaX) > Math.abs(e.deltaY);
    if (!sideways && !e.shiftKey) return; // let the page scroll
    e.preventDefault();
    s.target += (sideways ? e.deltaX : e.deltaY) * 1.1;
  }, { passive: false });

  let startX = 0;
  let moved = 0;
  stage.addEventListener('pointerdown', (e) => {
    dragging = true;
    moved = 0;
    startX = e.clientX;
    try { stage.setPointerCapture(e.pointerId); } catch { /* synthetic event */ }
    stage.classList.add('is-dragging');
  });
  stage.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    const dx = e.clientX - startX;
    startX = e.clientX;
    moved += Math.abs(dx);
    s.target -= dx * 1.5;
  });
  const end = (e) => {
    if (!dragging) return;
    dragging = false;
    stage.classList.remove('is-dragging');
    try { stage.releasePointerCapture(e.pointerId); } catch { /* already released */ }
    if (moved < 6) {
      const hit = document.elementFromPoint(e.clientX, e.clientY)?.closest('.ps-card');
      if (hit) onOpen(hit.dataset.open);
    }
  };
  stage.addEventListener('pointerup', end);
  stage.addEventListener('pointercancel', end);
  strip.addEventListener('keydown', (e) => {
    const card = e.target.closest('.ps-card');
    if (card && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); onOpen(card.dataset.open); }
  });
  const scope = root.closest('section') || root;
  const nudge = (dir) => {
    s.target += dir * step;
    if (!running) { s.current = s.target; place(); }
    if (reduced) place();
  };
  scope.querySelector('[data-ps-prev]')?.addEventListener('click', () => nudge(-1));
  scope.querySelector('[data-ps-next]')?.addEventListener('click', () => nudge(1));

  measure();
  place();
  new ResizeObserver(() => { measure(); place(); }).observe(stage);
  new IntersectionObserver(([entry]) => {
    if (entry.isIntersecting && !document.hidden) start(); else stop();
  }, { rootMargin: '200px' }).observe(root);
  document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); });
  if (reduced) { s.target = 0; place(); }

  return { pause: stop, resume: start };
}

/* ------------------------------------------------------------- case drawer */

const drawer = document.querySelector('#case-drawer');
const drawerBody = drawer?.querySelector('.case-body');
let currentCase = null;
let carousel = null;

function renderCase(p) {
  if (!access) return renderTeaser(p);
  const links = p.links.map((l) => `<a class="case-link" href="${esc(l.url)}" target="_blank" rel="noopener noreferrer">${esc(l.label)} <span aria-hidden="true">↗</span></a>`).join('');
  const gallery = (p.gallery || []).slice(1).map((src) => `<img src="${esc(src)}" alt="" loading="lazy" decoding="async"/>`).join('');
  return `
    <div class="case-cover">${cover(p, { big: true })}</div>
    <p class="case-kicker"><span>${esc(p.kind)}</span><span>${esc(p.category)}</span></p>
    <h2 id="case-title">${esc(p.name)}</h2>
    <p class="case-headline">${esc(p.headline)}</p>
    <p class="case-teaser">${esc(p.teaser)}</p>
    <div class="case-locked">
      <div class="case-full">
        <dl>
          <div><dt>The problem</dt><dd>${esc(p.problem)}</dd></div>
          <div><dt>What we did</dt><dd>${esc(p.did)}</dd></div>
          <div><dt>What we used</dt><dd><ul class="case-stack">${p.stack.map((t) => `<li>${esc(t)}</li>`).join('')}</ul></dd></div>
        </dl>
        ${gallery ? `<div class="case-gallery">${gallery}</div>` : ''}
        <div class="case-actions">${links}</div>
      </div>
    </div>`;
}

// Signed-out view: the real details are never put on the page, only
// placeholder bars behind the sign-in card.
function renderTeaser(p) {
  const bars = (n) => Array.from({ length: n }, (_, i) => `<i style="width:${[92, 78, 86, 64, 71][i % 5]}%"></i>`).join('');
  return `
    <div class="case-cover">${cover(p, { big: true })}</div>
    <p class="case-kicker"><span>${esc(p.kind)}</span><span>${esc(p.category)}</span></p>
    <h2 id="case-title">${esc(p.name)}</h2>
    <p class="case-headline">${esc(p.headline)}</p>
    <p class="case-teaser">${esc(p.teaser)}</p>
    <div class="case-locked is-locked">
      <div class="case-ghost" aria-hidden="true">
        <b>The problem</b><span>${bars(2)}</span>
        <b>What we did</b><span>${bars(4)}</span>
        <b>What we used</b><span class="ghost-chips"><i></i><i></i><i></i></span>
        <b>Live link</b><span>${bars(1)}</span>
      </div>
      <div class="case-gate">
        <span class="gate-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg></span>
        <h3>This project is locked.</h3>
        <p>Share your name, email and contact number to see the problem, what we built, the stack and the live link.</p>
        <button class="gate-btn" type="button" data-signin="${p.id}">Fill the form to view <span aria-hidden="true">↗</span></button>
      </div>
    </div>`;
}

function openCase(id) {
  const p = byId[id];
  if (!p || !drawer) return;
  currentCase = p;
  drawerBody.innerHTML = renderCase(p);
  drawerBody.scrollTop = 0;
  if (!drawer.open) drawer.showModal();
  document.documentElement.classList.add('case-open');
  carousel?.pause();
  if (access) viewed.add(p.name);
  history.replaceState(null, '', `#${p.id}`);
}

function closeCase() {
  if (drawer?.open) drawer.close();
}

drawer?.addEventListener('close', () => {
  document.documentElement.classList.remove('case-open');
  carousel?.resume();
  currentCase = null;
  history.replaceState(null, '', location.pathname + location.search);
});
drawer?.addEventListener('click', (e) => {
  if (e.target === drawer || e.target.closest('[data-close-case]')) closeCase();
  const signin = e.target.closest('[data-signin]');
  if (signin) openAccess(signin.dataset.signin);
});

/* --------------------------------------------------------- sign-in dialog */

const accessDialog = document.querySelector('#access-dialog');
const accessForm = accessDialog?.querySelector('form');
let pendingProject = null;

function openAccess(projectId = null) {
  if (!accessDialog) return;
  pendingProject = projectId;
  const p = projectId ? byId[projectId] : null;
  accessDialog.querySelector('[data-access-project]').textContent = p ? `Unlocking: ${p.name}` : 'Unlocks every project on this page';
  accessForm.querySelector('[name="project_of_interest"]').value = p ? p.name : '';
  accessForm.querySelector('.access-status').textContent = '';
  if (drawer?.open) drawer.close();
  accessDialog.showModal();
  accessForm.querySelector('[name="name"]').focus();
}

accessDialog?.addEventListener('click', (e) => {
  if (e.target === accessDialog || e.target.closest('[data-close-access]')) accessDialog.close();
});

accessForm?.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!accessForm.reportValidity()) return;
  if (accessForm.querySelector('[name="_gotcha"]').value) return; // bot
  const f = Object.fromEntries(new FormData(accessForm).entries());
  const btn = accessForm.querySelector('[type="submit"]');
  const status = accessForm.querySelector('.access-status');
  btn.disabled = true;
  btn.firstChild.textContent = 'Sending… ';
  const payload = {
    _subject: `Our Work lead: ${f.name} — ${f.company || 'no company'}${f.project_of_interest ? ` (looking at ${f.project_of_interest})` : ''}`,
    form_type: 'Our Work lead (projects unlocked)',
    name: f.name,
    email: f.email,
    _replyto: f.email,
    company: f.company,
    phone: f.phone,
    project_of_interest: f.project_of_interest,
  };
  try {
    await send(payload);
  } catch {
    // Don't lock a real visitor out because the form service hiccuped.
    store.set(PENDING_KEY, payload);
  }
  window.gtag?.('event', 'generate_lead', { form: 'our_work_signin' });
  access = { name: f.name, email: f.email, company: f.company, phone: f.phone, ts: Date.now() };
  store.set(ACCESS_KEY, access);
  applyAccess();
  btn.disabled = false;
  btn.firstChild.textContent = 'Submit and view projects ';
  status.textContent = '';
  accessDialog.close();
  accessForm.reset();
  toast(`Thank you, ${f.name.split(' ')[0]}. The projects are now open.`);
  if (pendingProject) openCase(pendingProject);
});

document.addEventListener('click', (e) => {
  const trigger = e.target.closest('[data-open-access]');
  if (trigger) {
    if (access && trigger.dataset.openAccess !== 'force') toast(`You can already view the projects, ${access.name.split(' ')[0]}. Tap any project to open it.`);
    else openAccess();
  }
  const out = e.target.closest('[data-signout]');
  if (out) {
    access = null;
    store.remove(ACCESS_KEY);
    applyAccess();
    toast('Projects locked again on this device.');
  }
});

function toast(text) {
  const el = document.querySelector('#work-toast');
  if (!el) return;
  el.textContent = text;
  el.classList.add('is-on');
  clearTimeout(toast.t);
  toast.t = setTimeout(() => el.classList.remove('is-on'), 3200);
}

window.addEventListener('pagehide', () => {
  if (!TRACK_VIEWS || !access || !viewed.size) return;
  send({
    _subject: `Our Work views: ${access.name} opened ${viewed.size} project${viewed.size > 1 ? 's' : ''}`,
    form_type: 'Our Work views',
    name: access.name,
    email: access.email,
    company: access.company,
    projects_viewed: [...viewed].join(', '),
  }, { beacon: true });
  viewed.clear();
});

/* -------------------------------------------------------------------- hero */

function hero() {
  const el = document.querySelector('.work-hero');
  if (!el) return;
  el.addEventListener('pointermove', (e) => {
    const r = el.getBoundingClientRect();
    el.style.setProperty('--mx', `${((e.clientX - r.left) / r.width) * 100}%`);
    el.style.setProperty('--my', `${((e.clientY - r.top) / r.height) * 100}%`);
  });
  const counts = { projects: allProjects.filter((p) => p.kind !== 'Research').length, research: allProjects.filter((p) => p.kind === 'Research').length };
  el.querySelectorAll('[data-count]').forEach((n) => {
    const to = counts[n.dataset.count] ?? Number(n.dataset.count);
    if (reduced) { n.textContent = to; return; }
    const t0 = performance.now();
    const run = (t) => {
      const k = Math.min(1, (t - t0) / 1400);
      n.textContent = Math.round(to * (1 - (1 - k) ** 3));
      if (k < 1) requestAnimationFrame(run);
    };
    requestAnimationFrame(run);
  });
}

/* ------------------------------------------- open a project from row 2 */

// Public client work scrolls to its card; products open the (locked) case study.
function openFromStrip(id) {
  const p = byId[id];
  const card = p?.open ? document.getElementById(id) : null;
  if (!card) { openCase(id); return; }
  card.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'center' });
  card.classList.remove('is-flash');
  void card.offsetWidth;
  card.classList.add('is-flash');
}

/* ------------------------------- client cards with more than one picture */

document.querySelectorAll('.project-visual.has-shot').forEach((visual) => {
  const shots = [...visual.querySelectorAll('.project-shot')];
  if (shots.length < 2 || reduced) return;
  let i = 0;
  visual.classList.add('rotating');
  shots.forEach((img, n) => img.classList.toggle('is-on', n === 0));
  setInterval(() => {
    if (document.hidden) return;
    shots[i].classList.remove('is-on');
    i = (i + 1) % shots.length;
    shots[i].classList.add('is-on');
  }, 3200);
});

/* -------------------------------------------------------------------- boot */

const sqRoot = document.querySelector('[data-squeeze]');
if (sqRoot) carousel = squeezeCarousel(sqRoot, featured, { onOpen: openCase });
const psRoot = document.querySelector('[data-perspective]');
if (psRoot) perspectiveStrip(psRoot, lab, { onOpen: openFromStrip });
hero();
applyAccess();
flushPending();

const deep = location.hash.slice(1);
if (byId[deep]) openCase(deep);
